# base64

This project boosts base64 encoding/decoding performance by utilizing SIMD
operations where possible.

The source is pulled from: https://github.com/aklomp/base64

Active development occurs in the default branch (currently named `master`).

## Updating

```sh
$ git clone https://github.com/aklomp/base64
```
